<?php

// Pricing Table -------------------------------------------------------------------------- >

function ttbase_framework_pricing_table_shortcode( $atts, $content = null ) {
	extract( 
		shortcode_atts( 
			array(
				'title' => '',
				'title_color' => '',
				'small' => '',
				'amount' => '$3',
				'button_text' => 'Select Plan',
				'button_url' => '',
				'button_style' => '',
				'layout' => 'basic'
			), $atts 
		) 
	);
	
	$button_url        = esc_url( $button_url );
	$title_style = ($title_color != '') ? ' style="color:' . esc_attr($title_color) . ';"' : '';
	if( 'basic' == $layout ){
		$output = '
			<div class="ttbase-pricing-table text-center">
		        <h5' . $title_style . '>'. htmlspecialchars_decode($title) .'</h5>
		        <span class="price">'. htmlspecialchars_decode($amount) .'</span>
		        <p class="lead">'. htmlspecialchars_decode($small) .'</p>
		        <a class="btn btn-primary ' . $button_style . '" href="'. $button_url  .'">'. htmlspecialchars_decode($button_text) .'</a>
		        '. wpautop(do_shortcode(htmlspecialchars_decode($content))) .'
		    </div>
	    ';
	} elseif( 'boxed' == $layout ) {
		$output = '
		    <div class="ttbase-pricing-table text-center boxed">
		        <h5' . $title_style . '>'. htmlspecialchars_decode($title) .'</h5>
		        <span class="price">'. htmlspecialchars_decode($amount) .'</span>
		        <p class="lead">'. htmlspecialchars_decode($small) .'</p>
		        <a class="btn btn-primary ' . $button_style . '" href="'. $button_url  .'">'. htmlspecialchars_decode($button_text) .'</a>
		        '. wpautop(do_shortcode(htmlspecialchars_decode($content))) .'
		    </div>
	    ';
	} else {
		$output = '
			<div class="ttbase-pricing-table text-center emphasis">
			    <h5' . $title_style . '>'. htmlspecialchars_decode($title) .'</h5>
			    <span class="price">'. htmlspecialchars_decode($amount) .'</span>
			    <p class="lead">'. htmlspecialchars_decode($small) .'</p>
			    <a class="btn btn-primary ' . $button_style. '" href="'. $button_url  .'">'. htmlspecialchars_decode($button_text) .'</a>
			    '. wpautop(do_shortcode(htmlspecialchars_decode($content))) .'
			</div>
		';
	}
	
	return $output;
}
add_shortcode( 'ttbase_pricing_table', 'ttbase_framework_pricing_table_shortcode' );

?>