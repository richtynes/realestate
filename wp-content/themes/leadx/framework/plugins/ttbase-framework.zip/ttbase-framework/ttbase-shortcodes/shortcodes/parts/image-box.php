<?php

// Icon Box -------------------------------------------------------------------------- >
function ttbase_framework_image_box_function( $atts, $content = null) {
		extract( shortcode_atts( array(
			'image' 					=> '',
			'overlay_color'             => '',
			'url'						=> 'http://',
			'target'					=> '_self',
			'icon_image'                => '',
			'icon_image_width'          => '',
			'icon_font'         		=> 'streamline',
            'icon_fa'                   => '',
            'icon_im'                   => '',
            'icon_sl'                   => '',
            'icon_color'                => '',
            'heading'                   => '',
            'heading_type'              => 'h2',
            'heading_color'             => '',
            'heading_size'              => '',
            'heading_weight'            => '',
            'heading_letter_spacing'    => '',
            'heading_transform'         => '',
            'heading_bottom_margin'     => '',
            'subtitle'                  => '',
            'subtitle_color'            => '',
            'subtitle_size'             => '',
            'subtitle_weight'           => '',
            'subtitle_transform'        => '',
            'subtitle_letter_spacing'   => '',
		), $atts ) );
		
		$output = '';
		
		$output .= '<a href="'.esc_url($url).'" target="' .esc_attr($target). '" class="ttbase-imagebox">';
		
		if($image != ''){
			$img_src = wp_get_attachment_image_src($image, 'standard');
			$output .= '<img class="img-responsive" src="'. $img_src[0] .'" />';
		}
		
		$overlay_style = '';
		if ($overlay_color) {
		    $overlay_style .= 'background-color:' . $overlay_color . ';';
            if ( '' != $overlay_style ) {
                $overlay_style = ' style="' . $overlay_style . '"';
            }
		}
		$output .= '<div class="ttbase-imagebox-overlay clearfix"'. $overlay_style .'>';
		$output.= '<div class="ttbase-imagebox-content">';
		/*** Image ***/
        if ( $icon_image ){
            $image_url = wp_get_attachment_url( $icon_image );
            $icon_image_style = '';
            if ( $icon_image_width ) {
                $icon_image_style = 'width:'. intval( $icon_image_width ) .'px;"';
            } 
            if ( '' != $icon_image_style ) {
                $icon_image_style = ' style="' . $icon_image_style . '"';
            }
            
            $output .= '<img class="ttbase-imagebox-img-alt" src="'. $image_url. '" alt="" ' .$icon_image_style. '/>';
        }
		elseif ($icon_fa || $icon_sl || $icon_im) {
			$icon_style = '';
			if ( $icon_color ) {
                $icon_style .= 'color:' . $icon_color . ';';
            }
            if ( '' != $icon_style ) {
                    $icon_style = ' style="' . $icon_style . '"';
                }
			if ( 'fontawesome' == $icon_font) {
            	$output .= '<i class="fa fa-'. $icon_fa .'"'. $icon_style .'></i>';
            }elseif ( 'iconsmind' == $icon_font) {
            	$output .= '<i class="im im-'. $icon_im .'"'. $icon_style .'></i>';
            } else {
                $output .= '<i class="sl sl-'. $icon_sl .'"'. $icon_style .'></i>';
            }
		}
		
		/** Heading ***/
        if ( $heading ) {
            // Heading Classes
            $add_classes ='';
            if ( $heading_weight ) {
                $add_classes .= 'font-weight-'. $heading_weight . ' ';
            }
            if ( $heading_transform ) {
                $add_classes .= 'text-transform-'. $heading_transform;
            }
            // Heading Style
            $heading_style = '';
            if ( '' != $heading_color ) {
                $heading_style .= 'color:'. $heading_color .';';
            }
            if ( '' != $heading_size ) {
                $heading_size = intval( $heading_size );
                $heading_style .= 'font-size:'. $heading_size .'px;';
            }
            if ( '' != $heading_letter_spacing ) {
                $heading_style .= 'letter-spacing:'. $heading_letter_spacing .';';
            }
            if ( $heading_bottom_margin ) {
                $heading_style .= 'margin-bottom:'. intval( $heading_bottom_margin ) .'px;';
            }
            if ( '' != $heading_style ) {
                $heading_style = ' style=' . $heading_style . '';
            }
            $output .= '<'. $heading_type .' class="ttbase-imagebox-heading '. $add_classes .'"'. $heading_style .'>';
            $output .= $heading;
            $output .= '</'. $heading_type .'>';
        }
        /** Subtitle ***/
        if ( $subtitle ) {
            // Subtitle Classes
            $add_classes ='';
            if ( $subtitle_weight ) {
                $add_classes .= 'font-weight-'. $subtitle_weight . ' ';
            }
            if ( $subtitle_transform ) {
                $add_classes .= 'text-transform-'. $subtitle_transform;
            }
            // Subtitle Style
            $subtitle_style = '';
            if ( '' != $subtitle_color ) {
                $subtitle_style .= 'color:'. $subtitle_color .';';
            }
            if ( '' != $subtitle_size ) {
                $subtitle_size = intval( $subtitle_size );
                $subtitle_style .= 'font-size:'. $subtitle_size .'px;';
            }
            if ( '' != $subtitle_letter_spacing ) {
                $subtitle_style .= 'letter-spacing:'. $subtitle_letter_spacing .';';
            }
            if ( '' != $subtitle_style ) {
                $subtitle_style = ' style=' . $inline_style . '';
            }
            $output .= '<p class="ttbase-imagebox-subtitle '. $add_classes .'"'. $subtitle_style . '>';
            $output .= $subtitle;
            $output .= '</p>';
        }
		$output .= '</div></div></a>';
			
		return $output;
	}
add_shortcode('ttbase_imagebox', 'ttbase_framework_image_box_function');
