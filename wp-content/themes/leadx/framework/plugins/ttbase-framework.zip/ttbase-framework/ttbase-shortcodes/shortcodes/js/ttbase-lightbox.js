jQuery(function($){
	$(document).ready(function(){
		$('.ttbase-shortcodes-lightbox').magnificPopup({
			type: 'image',
			gallery: { enabled: false }
		});
	});
});